#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<errno.h>
#include<stdbool.h>
#include<sys/wait.h>
#include<sys/types.h>
#include "resources.h"
#define PRINTERS 2
#define SCANNERS 1
#define MODEMS 1
#define DRIVES 2

struct proc* input_queue = NULL;
struct proc* real_time_queue = NULL;
struct proc* user_job_queue = NULL;
struct proc* priority_one_queue = NULL;
struct proc* priority_two_queue = NULL;
struct proc* priority_three_queue = NULL;


struct proc* curr_process = NULL;
struct proc* process = NULL;

struct mem* memory = NULL;
struct mem* memory_res = NULL;

struct res* resource = NULL;

unsigned int timer = 0;

/*void print();
void fill_input_queue(char* filename, FILE* fd);
void initialize();
bool finish();
void check_input_queue()
void check_user_job_queue();
void handle_curr_process();
void assign_curr_process();*/
