#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

typedef struct queue{
int data;
int priority;//lower values reps higher priority
struct queue* next;

}queue;

queue* new(int dat, int pri){
queue* tmp = (queue*)malloc(sizeof(queue));
tmp->data = dat;
tmp->priority = pri;
tmp->next = NULL;
return tmp;
}

int peek(queue** head){
return(*head)->data;
}

void pop(queue** head){
queue* tmp = *head;
(*head) = (*head)->next;
free(tmp);
}

void push(queue** head, int dat, int pri){
queue* start = (*head);
queue* tmp = new(dat, pri);

if((*head)->priority > pri){
tmp->next = *head;
(*head) = tmp;

}
}
