#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<errno.h>
#include<stdbool.h>
#include<sys/wait.h>
#include<sys/types.h>

#include "process.h"

struct proc* create_null_proc(){
struct proc* pri = (struct proc*)malloc(sizeof(struct proc));
pri->pid = 0;
pri->buff[0] = DEF_PROC;
pri->buff[1] = NULL;
pri->arrival_time = 0;
pri->priority = 0;
pri->rem_cpu_time = 0;
pri->status = UNINITIALIZED;
pri->printers_num = 0;
pri->scanners_num = 0;
pri->modems_num = 0;
pri->drives_num = 0;
pri->mbytes;
}

struct proc* start_proc(struct proc* pri){
	if((pri->pid) == 0){
	pri->pid = fork();
	if((pri->pid = fork()) < 0){
	exit(1);
	}
	else if(pri->pid == 0){
	pri->pid = getpid();
	pri->status = RUNNING;
	fflush(stdout);
	execvp(pri->buff[0], pri->buff);
	exit(2);
	}
	}
	else{
	kill(pri->pid, SIGCONT);
	}
	pri->status = RUNNING;
	return pri;
}

struct proc* suspend_proc(struct proc* pri){
int status;
kill(pri->pid, SIGTSTP);
waitpid(pri->pid, &status, WUNTRACED);
pri->status = SUSPENDED;
return pri;
}

struct proc* restart_proc(struct proc* pri)
{
    kill(pri->pid, SIGCONT);  // Send a continue signal to process
    return pri;
}

struct proc* terminate_proc(struct proc* pri){
int status;
kill(pri->pid, SIGINT);
waitpid(pri->pid, &status, WUNTRACED);
pri->status = TERMINATED;
return pri;
}

struct proc* enqueue_proc(struct proc* head, struct proc* pri){
	struct proc* currproc = head;
	if(head){
	while(currproc->next){
	currproc = currproc->next;
	}
	currproc->next = pri;
	return head;
	}
	else{
	return pri;
	}
}

struct proc* dequeue_proc(struct proc* head){
if(!head){
return NULL;
}
else{
struct proc* nhead = head->next;
head->next = NULL;
return nhead;
}
}
