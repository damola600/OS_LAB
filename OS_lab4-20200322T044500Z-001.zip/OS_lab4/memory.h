#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<errno.h>
#include<stdbool.h>
#include<sys/wait.h>
#include<sys/types.h>

struct mem{
unsigned int offset;
unsigned int size;
int allocated;
struct mem* prev;
struct mem* next;
}mem;

struct mem* create_null_mem();
struct mem* fit_mem(struct mem* mem_block, unsigned int size);
struct mem* allocate_mem(struct mem* mem_block, unsigned int size);
struct mem* free_mem(struct mem* mem_block);
struct mem* split_mem(struct mem* mem_block, unsigned int size);
struct mem* merge_mem(struct mem* mem_block);

