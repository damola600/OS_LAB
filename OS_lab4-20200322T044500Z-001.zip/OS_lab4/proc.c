#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

//memory contraints
#define MEMORY 1024
#define RESERVED_MEMORY 64

//resource contraints
#define PRINTERS 2
#define SCANNER 1
#define MODEM 1
#define CD 2

//argument size for process
#define MAX_ARGS 3
//sigtrap.c call
#define DEFAULT_PROCESS "./process"

// Status codes for each process
#define PCB_UNINITIALIZED   0
#define PCB_INITIALIZED     1
#define PCB_READY           2
#define PCB_RUNNING         3
#define PCB_SUSPENDED       4
#define PCB_TERMINATED      5

//process
typedef struct proc
{
	pid_t pid; //process id   
	char* args[MAX_ARGS]; //time process arrives in queue
	unsigned int arrival_time;  // Time process arrives in queue
	unsigned int priority;  // Priority of process (0 for real-time, 1-3 for user job)
	unsigned int remaining_cpu_time;    // Time left until process is completed
	unsigned int status;    // Current status of process

	unsigned int num_printers;  // Number of printers required by process
	unsigned int num_scanners;  // Number of scanners required by process
	unsigned int num_modems;    // Number of modems required by process
	unsigned int num_drives;    // Number of drives required by process
	unsigned int mbytes;    // Memory requirement of process in mbytes

	struct mab* mem_block;  // Pointer to memory block for process (if it has been allocated)

	struct pcb* next;   // Pointer to next process (if in queue)
}proc;

//queue
typedef struct queue
{
    proc process;
    struct queue *next; 
}queue;

//resources
typedef struct resources{
	int printers;
	int scanner;
	int modem;
	int CD;
	int avail_mem[MEMORY];
}resources;

/*void print(queue *in_queue)
{
    queue *printlist = in_queue->next;
    while(printlist != NULL)
    {
        printf("%s ",printlist->process.name);
        printf("%d ",printlist->process.priority);
        printf("%d ",printlist->process.pid);
        printf("%d ",printlist->process.address);
        printf("%d ",printlist->process.memory);
        printf("%d ",printlist->process.runtime);
        printf("%d \n",printlist->process.suspended);
        printlist = printlist->next;
    }
} 
void print_proc(proc process)
{
    printf("name: %s\n",process.name);
    printf("priority: %d\n",process.priority);
    printf("pid: %d\n",process.pid);
    printf("address: %d\n",process.address);
    printf("memory: %d\n",process.memory);
    printf("runtime: %d\n",process.runtime);
    printf("suspended: %d\n",process.suspended);
}*/
void push(proc process,queue *in_queue)
{
    queue *new_node;
    new_node = (queue*) malloc(sizeof(queue));
    new_node->process = process;
    new_node->next = NULL;
    queue *current = in_queue;
    while(current->next != NULL)
    {
        current = current->next;
    }
    current->next = new_node;
    // printf("%s\n",in_queue->next->process.name);
   
    
}
proc pop(queue *in_queue)
{
    proc process = in_queue->next->process;
    queue *current = in_queue->next;
    in_queue->next = current->next;
    free(current);
    return process;    
}

//read the process
void read_proc(queue* real_time, queue *priority_1, queue *priority_2, queue *priority_3)
{ 
    FILE *open;
    open = fopen("dispatchlist","r");
    char pname_buffer[200];
    int priority_buffer;
    int memory_buffer;
    int pruntime_buffer;
    while(fscanf(open,"%s %d%*c %d%*c %d",pname_buffer,&priority_buffer,&memory_buffer,&pruntime_buffer)>0)
    {
        proc process;
        pname_buffer[strlen(pname_buffer)-1] = '\0';
        strcpy(process.name,pname_buffer);
        process.priority = priority_buffer;
        process.pid = 0;
        process.address = 0;
        process.memory = memory_buffer;
        process.runtime = pruntime_buffer;
        process.suspended = false;
        if(process.priority == 0)
            push(process,priority);
        else
            push(process,secondary);    
    }
}

//free memory and resources
void release_memory(int *avail_mem,int from,int to)
{
    for (int i = from; i < to; i++)
    {
        avail_mem[i] = 0;  
    }
}

//memory allocation
int hold_memory(int *avail_mem,int from,int to)
{
	int start_index = -1;
	int count = 1;
	int mem[MEMORY];
	for(int i = 0; i < MEMORY; i++)
		mem[i] = avail_mem[i];

	for(int i = from; i < to; i++)
	{
		/*if(i >= 959){
			printf("Reserved for real time processes.");	
		}*/
		if(mem[i] != 0)
		{
		    return false;
		} else if(mem[i] == 0 && count != 1){
			start_index = i;
			count--;
		}
		mem[i] = 1;
	}
	for(int i = 0; i < MEMORY; i++)
		avail_mem[i] = mem[i];

	return start_index;
}

int main(void)
{
	//resources initialization
	resources *res_avail;
	res_avail = (resources*)malloc(sizeof(resources));
	res_avail->printers = 2;
	res_avail->scanner = 1;
	res_avail->modem = 1;
	res_avail->CD = 2;
	//memory array
   	res_avail->avail_mem = {0};

	//queues
	queue *real_time;
	queue *priority_1; 
	queue *priority_2; 
	queue *priority_3; 
	int status;
	real_time = (queue*)malloc(sizeof(queue));
	priority_1 = (queue*)malloc(sizeof(queue));
	priority_2 = (queue*)malloc(sizeof(queue));
	priority_3 = (queue*)malloc(sizeof(queue));
	real_time->next = NULL;
	priority_1->next = NULL;
	priority_2->next = NULL;
	priority_3->next = NULL;

	bool enough_space = false;
	read_proc(real_time, priority_1, priority_2, priority_3);
    while(priority->next != NULL)
    {
        int i = 0;
        while(i < MEMORY && !enough_space)
        {
            if(avail_mem[i] == 0)
            {
                enough_space =  hold_memory(avail_mem,i,priority->next->process.memory+i);
            }
            i++;
        }
        if(enough_space)
        {
            priority->next->process.address = i-1;
            enough_space = false;
            pid_t pid;
            pid = fork();
            if(pid != 0)//parent
            {
                proc process;
                priority->next->process.pid = pid;
                process = pop(priority);
                print_proc(process);
                wait(NULL);
                release_memory(avail_mem,i-1,process.memory);
            } 
            else
            {
                char runtime[20] = "";
                sprintf(runtime,"%d",priority->next->process.runtime);
                execl("process","process",runtime,NULL);
            }
        }
        else
        {
            proc process = pop(priority);
            push(process,priority);
        }    
    }
    while(secondary->next != NULL)
    {
        enough_space = false;
        int i = 0;
        while(i < MEMORY && !enough_space)
        {
            if(avail_mem[i] == 0)
            {
                enough_space =  hold_memory(avail_mem,i,secondary->next->process.memory+i);
                if(enough_space)
                    secondary->next->process.address = i;
            }
            i++;
        }
        if(enough_space && !secondary->next->process.suspended)
        {
            pid_t pid;
            pid = fork();
            if(pid != 0)//parent
            {
                
                secondary->next->process.pid = pid;
                if(secondary->next->process.runtime == 1)
                {
                    proc process;
                    process = pop(secondary);
                    print_proc(process);
                    waitpid(pid, &status, 0);
                    release_memory(avail_mem,process.address,process.memory+process.address);
                }
                else
                {
                    proc process;
                    process = pop(secondary);
                    print_proc(process);
                    sleep(1);
                    kill(pid,SIGTSTP);
                    process.suspended = true;
                    push(process,secondary);
                }
            } 
            else
            {
                char runtime[20] = "";
                sprintf(runtime,"%d",secondary->next->process.runtime);
                execl("process","process",runtime,NULL);
            }
        }
        else
        {
            proc process = pop(secondary);
            push(process,secondary);
        }
        if(secondary->next->process.suspended)
        {
            proc process;
            kill(secondary->next->process.pid,SIGCONT);
            waitpid(secondary->next->process.pid,&status, 0);
            process = pop(secondary);
            release_memory(avail_mem,process.address,process.address+process.memory);
            
        }  
    }
}
