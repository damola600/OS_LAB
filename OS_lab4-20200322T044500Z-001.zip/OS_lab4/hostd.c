#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<errno.h>
#include<stdbool.h>
#include<sys/wait.h>
#include<sys/types.h>
#include "hostd.h"

#define MEM_RES 64
#define MEM_TOT 1024

void print(){
	printf("provide a file\n");
}

void enqueue_input_queue(char* filename, FILE* fd){
	struct proc* process;
	char buf[50];
	fd = fopen(filename, "r");
	while(fgets(buf, 50, fd)){

		if(buf[0] == '\n'){
			break;
		}

		process = create_null_proc();
		char* sym = strtok(buf, ",");
		int num [8];
		int x= 0 ;

		while(sym){
			int n = atoi(sym);
			sym = strtok(NULL, ",");
			num[x] = n;
			++x;
		}
		process->arrival_time = num[0];
		process->priority = num[1];
		process->rem_cpu_time = num[2];
		process->mbytes = num[3];
		process->printers_num = num[4];
		process->scanners_num = num[5];
		process->modems_num = num[6];
		process->drives_num = num[7];

		input_queue = enqueue_proc(input_queue, process);
		process = NULL;
	}
	fclose(fd);
}

void initialize(){
	memory = create_null_mem();
	memory->size = MEM_TOT - MEM_RES;
	memory_res = create_null_mem();
	memory_res->size = MEM_RES;
	resource = create_null_res();
	resource->printers_rem = PRINTERS;
	resource->scanners_rem = SCANNERS;
	resource->modems_rem = MODEMS;
	resource->drives_rem = DRIVES;
}

bool finish(){
	return(!input_queue && !real_time_queue && !user_job_queue && !priority_one_queue && !priority_two_queue && !priority_three_queue && !curr_process);
}

void check_input_queue(){
	while(input_queue && input_queue->arrival_time <= timer){
		struct proc* pri = input_queue;
		input_queue = dequeue_proc(input_queue);
		if(pri->priority == 0){
			real_time_queue = enqueue_proc(real_time_queue, pri);
		}
		else{
			user_job_queue = enqueue_proc(user_job_queue, pri);
		}
	}
}

void check_user_job_queue(){
	while(user_job_queue && fit_mem(memory, user_job_queue->mbytes) && check_res(user_job_queue, resource)){
		struct proc* pri = user_job_queue;
		user_job_queue = dequeue_proc(user_job_queue);
		allocate_res(pri, resource);
		switch(pri->priority){
			case 1:
				priority_one_queue = enqueue_proc(priority_one_queue, pri);
				break;
			case 2:
				priority_two_queue = enqueue_proc(priority_two_queue, pri);
				break;
			default:
				priority_three_queue = enqueue_proc(priority_three_queue, pri);
				break;
			}
	}
}
	
void handle_curr_process(){
	if(--curr_process->rem_cpu_time == 0){
		terminate_proc(curr_process);
		free_mem(curr_process->mem_block);
		free_res(curr_process, resource);
		free(curr_process);
		curr_process = NULL;
	}else{
		if((real_time_queue || user_job_queue || priority_one_queue || priority_two_queue || priority_three_queue) && (curr_process->priority != 0)){
			struct proc* pri = suspend_proc(curr_process);
			if(++pri->priority > 3){
				pri->priority = 3;
			}
			switch(pri->priority){
				case 1:
					priority_one_queue = enqueue_proc(priority_one_queue, pri);
					break;
				case 2:
					priority_two_queue = enqueue_proc(priority_two_queue, pri);
					break;
				default:
					priority_three_queue = enqueue_proc(priority_three_queue, pri);
					break;
			}
			curr_process = NULL;
		}
	}
}

void assign_curr_process(){
	if(real_time_queue){
		curr_process = real_time_queue;
		real_time_queue = dequeue_proc(real_time_queue);
	}else if(priority_one_queue){
		curr_process = priority_one_queue;
		priority_one_queue = dequeue_proc(priority_one_queue);	
	}else if(priority_two_queue){
		curr_process = priority_two_queue;
		priority_two_queue = dequeue_proc(priority_two_queue);
	}else if(priority_three_queue){
		curr_process = priority_three_queue;
		priority_three_queue = dequeue_proc(priority_three_queue);	
	}

	if(curr_process->pid != 0){
		restart_proc(curr_process);
	}else{
		start_proc(curr_process);
		if(curr_process->priority == 0){
			curr_process->mem_block = allocate_mem(memory_res, curr_process->mbytes);
		}else{
			curr_process->mem_block = allocate_mem(memory, curr_process->mbytes);
		}
	}
}

int main(int argc, char* argv[]){
	char* filename;
	FILE* fd;

	if(argc == 2){
		filename = argv[1];
	}else{
		print();
		exit(0);
	}
	if(!(fd = fopen(filename, "r"))){
		printf("error opening file");
		exit(0);
	}

	enqueue_input_queue(filename, fd);
	initialize();

	while(!finish()){
		check_input_queue();
		check_user_job_queue();
		if(curr_process){
			handle_curr_process();
		}
		if((real_time_queue || priority_one_queue || priority_two_queue || priority_three_queue) && (!curr_process)){
			assign_curr_process();
		}
		sleep(1);
		timer += 1;
	}
	printf("processes finished\n");
	return 0;
}

