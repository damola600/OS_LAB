#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<errno.h>
#include<stdbool.h>
#include<sys/wait.h>
#include<sys/types.h>
#include "process.h"

struct res{
unsigned int printers_rem;
unsigned int scanners_rem;
unsigned int modems_rem;
unsigned int drives_rem;
}res;

struct res*  create_null_res();
bool check_res(struct proc* pri, struct res* resource);
void allocate_res(struct proc* pri, struct res* resource);
void free_res(struct proc* pri, struct res* resource);
