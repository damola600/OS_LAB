#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<errno.h>
#include<stdbool.h>
#include<sys/wait.h>
#include<sys/types.h>

#include "memory.h"

#define LEN 3

#define DEF_PROC "./process"

#define UNINITIALIZED 0
#define INITIALIZED 1
#define READY 2
#define RUNNING 3
#define SUSPENDED 4
#define TERMINATED 5

struct proc{
pid_t pid;
char* buff[LEN];
unsigned int arrival_time;
unsigned int priority;
unsigned int rem_cpu_time;
unsigned int status;

unsigned int printers_num;
unsigned int scanners_num;
unsigned int modems_num;
unsigned int drives_num;
unsigned int mbytes;

struct mem* mem_block;
struct proc* next;
}proc;

struct proc* create_null_proc();
struct proc* start_proc(struct proc* pri);
struct proc* suspend_proc(struct proc* pri);
struct proc* restart_proc(struct proc* pri);
struct proc* terminate_proc(struct proc* pri);
struct proc* enqueue_proc(struct proc* pri, struct proc* proc);
struct proc* dequeue_proc(struct proc* pri);
