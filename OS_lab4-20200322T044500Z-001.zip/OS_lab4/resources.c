#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<errno.h>
#include<stdbool.h>
#include<sys/wait.h>
#include<sys/types.h>

#include "resources.h"

struct res* create_null_res(){
struct res* resource = (struct res*)malloc(sizeof(struct res));
resource->printers_rem = 0;
resource->scanners_rem = 0;
resource->modems_rem = 0;
resource->drives_rem = 0;
return resource;
}

bool check_res(struct proc* pri, struct res* resource){
return(resource->printers_rem >= pri->printers_num && resource->scanners_rem >= pri->scanners_num && resource->modems_rem >= pri->modems_num && resource->drives_rem >= pri->drives_num);
}

void allocate_res(struct proc* pri, struct res* resource){
resource->printers_rem -= pri->printers_num;
resource->scanners_rem -= pri->scanners_num;
resource->modems_rem -= pri->modems_num;
resource->drives_rem -= pri->drives_num;
}

void free_res(struct proc* pri, struct res* resource){
resource->printers_rem += pri->printers_num;
resource->scanners_rem += pri->scanners_num;
resource->modems_rem += pri->modems_num;
resource->drives_rem += pri->drives_num;
}
