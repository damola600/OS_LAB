#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<errno.h>
#include<stdbool.h>
#include<sys/wait.h>
#include<sys/types.h>

#include "memory.h"

struct mem* create_null_mem(){
struct mem* memp = (struct mem*)malloc(sizeof(struct mem));
memp->offset = 0;
memp->size = 0;
memp->allocated = false;
memp->prev = NULL;
memp->next = NULL;
return memp;
}

struct mem* fit_mem(struct mem* mem_block, unsigned int size){
struct mem* memp = mem_block;
while(memp){
if(!memp->allocated && memp->size >= size){
return memp;
}
memp = memp->next;
}
return NULL;
}

struct mem* allocate_mem(struct mem* mem_block, unsigned int size){
struct mem* memp = mem_block;
memp = fit_mem(mem_block, size);
if(memp){
memp = split_mem(memp, size);
if(memp){
memp->allocated = true;
}
}
return memp;
}

struct mem* free_mem(struct mem* mem_block){
	/*if(!mem_block->allocated && size <= mem_block->size){
		if(mem_block->size > size){
			struct mem* new_mem_block = create_null_mem();
			new_mem_block->offset = mem_block->offset + size;
			new_mem_block->size = mem_block->size - size;
			mem_block->size = size;
			new_mem_block->next = mem_block->next;
			mem_block->next = new_mem_block;
			new_mem_block->prev = mem_block;
		}
		return mem_block;
	}
	return NULL;*/
	mem_block->allocated = false;
	merge_mem(mem_block);
	merge_mem(mem_block->prev);
}

struct mem* split_mem(struct mem* mem_block, unsigned int size)
{
    if (!mem_block->allocated && size <= mem_block->size)   // Make sure block is unallocated and size is large enough
    {
        if (mem_block->size > size) // If size is bigger than desired size, split the block
        {
            struct mem* new_mem_block = create_null_mem();
            new_mem_block->offset = mem_block->offset + size;
            new_mem_block->size = mem_block->size - size;
            mem_block->size = size;
            new_mem_block->next = mem_block->next;
            mem_block->next = new_mem_block;
            new_mem_block->prev = mem_block;
        }
        return mem_block;   // If the size is exact, no need to split. Just return the block
    }
    return NULL;
}

struct mem* merge_mem(struct mem* mem_block){
if(mem_block && !mem_block->allocated && mem_block->next && !mem_block->next->allocated){
struct mem* next_mem_block = mem_block->next;
mem_block->size += next_mem_block->size;
mem_block->next = next_mem_block->next;
if(next_mem_block->next){
next_mem_block->next->prev = mem_block;
}
}
return mem_block;
}
